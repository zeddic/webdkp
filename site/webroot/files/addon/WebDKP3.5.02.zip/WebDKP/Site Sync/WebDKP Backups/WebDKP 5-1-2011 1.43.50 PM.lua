
WebDKP_Log = {
	["Version"] = 2,
	["Mercurial Hood 2011-05-01 12:51:06"] = {
		["awarded"] = {
			["Zealer"] = {
				["class"] = "Priest",
				["guild"] = "Nothing to Lose",
				["name"] = "Zealer",
			},
		},
		["zone"] = "Stormwind City",
		["date"] = "2011-05-01 12:51:06",
		["reason"] = "Mercurial Hood",
		["foritem"] = "true",
		["awardedby"] = "Zealer",
		["itemid"] = "60256",
		["points"] = -1,
		["itemlink"] = "|cffa335ee|Hitem:60256:0:0:0:0:0:0:0:85:0|h[Mercurial Hood]|h|r",
		["tableid"] = 1,
	},
	["Mercurial Hood 2011-05-01 12:51:12"] = {
		["awarded"] = {
			["Zealer"] = {
				["class"] = "Priest",
				["guild"] = "Nothing to Lose",
				["name"] = "Zealer",
			},
		},
		["zone"] = "Stormwind City",
		["date"] = "2011-05-01 12:51:12",
		["reason"] = "Mercurial Hood",
		["foritem"] = "true",
		["awardedby"] = "Zealer",
		["itemid"] = "65235",
		["points"] = -1,
		["itemlink"] = "|cffa335ee|Hitem:65235:0:0:0:0:0:0:0:85:0|h[Mercurial Hood]|h|r",
		["tableid"] = 1,
	},
	["Mercurial Shoulderwraps 2011-05-01 13:02:31"] = {
		["awarded"] = {
			["Zealer"] = {
				["class"] = "Priest",
				["guild"] = "Nothing to Lose",
				["name"] = "Zealer",
			},
		},
		["zone"] = "Stormwind City",
		["date"] = "2011-05-01 13:02:31",
		["reason"] = "Mercurial Shoulderwraps",
		["foritem"] = "true",
		["awardedby"] = "Zealer",
		["itemid"] = "65238",
		["points"] = -98,
		["itemlink"] = "|cffa335ee|Hitem:65238:0:0:0:0:0:0:0:85:0|h[Mercurial Shoulderwraps]|h|r",
		["tableid"] = 1,
	},
	["Test 2011-05-01 12:45:28"] = {
		["awarded"] = {
			["Zealer"] = {
				["class"] = "Priest",
				["guild"] = "Nothing to Lose",
				["name"] = "Zealer",
			},
		},
		["zone"] = "Stormwind City",
		["date"] = "2011-05-01 12:45:28",
		["reason"] = "Test",
		["foritem"] = "false",
		["awardedby"] = "Zealer",
		["points"] = 100,
		["itemlink"] = "Test",
		["tableid"] = 1,
	},
	["Mercurial Leggings 2011-05-01 13:08:57"] = {
		["awarded"] = {
			["Zealer"] = {
				["guild"] = "Nothing to Lose",
				["name"] = "Zealer",
			},
		},
		["zone"] = "Stormwind City",
		["date"] = "2011-05-01 13:08:57",
		["reason"] = "Mercurial Leggings",
		["foritem"] = "true",
		["awardedby"] = "Zealer",
		["itemlink"] = "|cffa335ee|Hitem:60255:0:0:0:0:0:0:0:85:0|h[Mercurial Leggings]|h|r",
		["points"] = -0,
		["itemid"] = "60255",
		["tableid"] = 1,
	},
}
WebDKP_DkpTable = {
}
WebDKP_Tables = {
}
WebDKP_Loot = {
}
WebDKP_Alts = {
}
WebDKP_WebOptions = {
	["CombineAlts"] = -0,
	["ZeroSumEnabled"] = -0,
}
