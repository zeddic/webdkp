------------------------------------------------------------------------
-- WEB DKP 2
------------------------------------------------------------------------
-- An addon to help manage the dkp for a guild. The addon provides a 
-- list of the dkp of all players as well as an interface to add / deduct dkp 
-- points. 
-- The addon generates a log file which can then be uploaded to a companion 
-- website at www.webdkp.com
------------------------------------------------------------------------

---------------------------------------------------
-- MEMBER VARIABLES
---------------------------------------------------
-- Sets the range of dkp that defines tiers.
-- Example, 50 would be:
-- 0-50 = teir 0
-- 51-100 = teir 1, etc
local WebDKP_TierInterval = 50;   

-- Specify what filters are turned on and off. 1 = on, 0 = off
-- (Don't mess around with)
local WebDKP_Filters = {
	["Druid"] = 1,
	["Hunter"] = 1,
	["Mage"] = 1,
	["Rogue"] = 1,
	["Shaman"] = 1,
	["Paladin"] = 1,
	["Priest"] = 1,
	["Warrior"] = 1,
	["Warlock"] = 1,
	["Group"] = 1
}

-- The dkp table itself (This is loaded from the saved variables file)
-- Its structure is:
-- ["playerName"] = {
--		["dkp"] = 100,
--		["class"] = "ClassName",
--		["Selected"] = true/ false if they are selected in the guid
-- }
WebDKP_DkpTable = {};

-- Holds the list of users tables on the site. This is used for those guilds
-- who have multiple dkp tables for 1 guild. 
-- When there are multiple table names in this list a drop down will appear 
-- in the addon so a user can select which table they want to award dkp to
-- Its structure is: 
-- ["tableName"] = { 
--		["id"] = 1 (this is the tableid of the table on the webdkp site)
-- }
WebDKP_Tables = {};
selectedTableid = 1;


-- The dkp table that will be shown. This is filled programmatically
-- based on running through the big dkp table applying the selected filters
local WebDKP_DkpTableToShow = {}; 

-- Keeps track of the current players in the group. This is filled programmatically
-- and is filled with Raid data if the player is in a raid, or party data if the
-- player is in a party. It is used to apply the 'Group' filter
local WebDKP_PlayersInGroup = {};

-- Keeps track of the sorting options. 
-- Curr = current columen being sorted
-- Way = asc or desc order. 0 = desc. 1 = asc
local WebDKP_LogSort = {
	["curr"] = 3,
	["way"] = 1 -- Desc
};

-- A reference to the original chat frame event hook (the one that we will replace)
-- Used to disguise our whisper messages
local WebDKP_ChatFrame_OnEvent_Original = nil; 

---------------------------------------------------
-- INITILIZATION
---------------------------------------------------
-- Uses Ace to initilize the addon and register events
--WebDKP = AceLibrary("AceAddon-2.0"):new("AceEvent-2.0", "AceConsole-2.0");
-- register the /webdkp slash command to toggle the gui
--local options =
--{
--   type = 'execute',
--    desc = "Show the gui",
--    func = "ToggleGUI"
--}
--WebDKP:RegisterChatCommand({"/WebDKP"},options)

---------------------------------------------------
-- START UP / SHUTDOWN METHODS
---------------------------------------------------

function WebDKP_OnLoad()
	SlashCmdList["WEBDKP"] = WebDKP_ToggleGUI;
	SLASH_WEBDKP1 = "/webdkp";
		
		
	-- Register for party / raid changes so we know to update the list of players in group
	this:RegisterEvent("PARTY_MEMBERS_CHANGED"); 
	this:RegisterEvent("RAID_ROSTER_UPDATE"); 
	this:RegisterEvent("CHAT_MSG_WHISPER"); 
	this:RegisterEvent("ITEM_TEXT_READY");
	this:RegisterEvent("ADDON_LOADED");
	
	WebDKP_OnEnable();
	
end

-- ================================
-- Called when the addon is enabled. 
-- Takes care of basic startup tasks: hide certain forms, 
-- get the people currently in the group, register for events, 
-- etc. 
-- ================================
function WebDKP_OnEnable()

	
	WebDKP_Frame:Hide();
	getglobal("WebDKP_FiltersFrame"):Show();
	getglobal("WebDKP_AwardDKP_Frame"):Hide();
	getglobal("WebDKP_AwardItem_Frame"):Hide();
	
	WebDKP_UpdatePlayersInGroup();
	WebDKP_UpdateTableToShow();
	

	-- place a hook on the chat frame so we can filter out our whispers
	WebDKP_Register_WhisperHook();
end


function WebDKP_OnEvent()
	if(event=="CHAT_MSG_WHISPER") then
		WebDKP_CHAT_MSG_WHISPER();
	elseif(event=="PARTY_MEMBERS_CHANGED") then
		WebDKP_PARTY_MEMBERS_CHANGED();
	elseif(event=="RAID_ROSTER_UPDATE") then
		WebDKP_RAID_ROSTER_UPDATE();
	elseif(event=="ITEM_TEXT_READY") then
		WebDKP_Print("Here!");
	elseif(event=="ADDON_LOADED") then
		WebDKP_ADDON_LOADED();
	end
end


function WebDKP_ADDON_LOADED()
	if( WebDKP_DkpTable == nil) then
		WebDKP_DkpTable = {};
	end
	
	if ( WebDKP_Tables == nil or next(WebDKP_Tables) == nil) then

		
	end


end



-- ================================
-- Called on shutdown. Does nothing
-- ================================
function WebDKP_OnDisable()
    
end

-- ================================
-- Places a hook on incoming whispers to the chat message box. 
-- We can use this to disguise our whisper messages
-- ================================
function WebDKP_Register_WhisperHook()
  if ( ChatFrame_OnEvent ~= WebDKP_ChatFrame_OnEvent_Hook ) then
        -- hook the chatframe onevent to allow us to hide the queue requrests if we want
        WebDKP_ChatFrame_OnEvent_Original = ChatFrame_OnEvent
        ChatFrame_OnEvent = WebDKP_ChatFrame_OnEvent_Hook
    end
end
---------------------------------------------------
-- EVENT HANDLERS
---------------------------------------------------

-- ================================
-- Called by slash command. Toggles gui. 
-- ================================
function WebDKP_ToggleGUI()
	-- self:Print("Should toggle gui now...")
	WebDKP_Refresh()
	WebDKP_Frame:Show();	
	WebDKP_Tables_DropDown_OnLoad();
end

-- ================================
-- Handles the master loot list being opened 
-- ================================
function WebDKP_OPEN_MASTER_LOOT_LIST()
    self:Print("Master loot list opened!");
end

-- ================================
-- Called when the party / raid configuration changes. 
-- Causes the list of current group memebers to be refreshed
-- so that filters will be ok
-- ================================
function WebDKP_PARTY_MEMBERS_CHANGED()
	-- self:Print("Party / Raid change");
	WebDKP_UpdatePlayersInGroup();
	WebDKP_UpdateTableToShow();
	WebDKP_UpdateTable();
end
function WebDKP_RAID_ROSTER_UPDATE()
	-- self:Print("Party / Raid change");
	WebDKP_UpdatePlayersInGroup();
	WebDKP_UpdateTableToShow();
	WebDKP_UpdateTable();
end



-- ================================
-- Event handler for regular chat whisper messages
-- Responds to the players whisper with a whisper telling
-- them their current dkp. 
-- ================================
function WebDKP_CHAT_MSG_WHISPER()
	local tableid = WebDKP_GetTableid();
	local name = arg2;
	local trigger = arg1;

	if ( WebDKP_IsWebDKPWhisper(name, trigger) ) then
		-- its a valid whisper for us. Now to determine what type of whisper
		if(trigger == "!dkp" ) then		-- THEY WANT THEIR DKP
			-- look up this player in our dkp table and see if we can find their information
			if ( WebDKP_DkpTable[name] == nil ) then
				-- not in our system, send them message
				WebDKP_SendWhisper(name,"You have no DKP history"); 
			else
				-- they are here, get them their dkp
				local dkp = WebDKP_DkpTable[name]["dkp_"..tableid];
				if( dkp == nil ) then
					WebDKP_DkpTable[name]["dkp_"..tableid] = 0;
				end 
				local tier = floor((dkp-1)/WebDKP_TierInterval);
				if(dkp == 0 ) then
					tier = 0;
				end
				WebDKP_SendWhisper(name,"Current DKP - "..dkp); 
				WebDKP_SendWhisper(name,"Tier - "..tier); 
			end	
		elseif(string.find(string.lower(trigger), "!listall")==1 ) then -- THEY WANT _ALL_ THE DKP OF EVERYONE
			local filter = WebDKP_GetWhisperFiltersFromMessage(trigger);
			WebDKP_SendWhisper(name,"DKP List");
			WebDKP_SendWhisper(name,"DKP - Tier Name(Class) ");
			WebDKP_SendWhisper(name,"==============================");
			WebDKP_WhisperSortedList(name,false,filter);
		elseif(string.find(string.lower(trigger), "!list")==1 ) then  -- THEY WANT THE DKP OF PEOPLE IN THE CURRENT GROUP
			local filter = WebDKP_GetWhisperFiltersFromMessage(trigger);
			WebDKP_SendWhisper(name,"DKP List");
			WebDKP_SendWhisper(name,"DKP - Tier Name(Class) ");
			WebDKP_SendWhisper(name,"==============================");
			WebDKP_WhisperSortedList(name,true,filter);
		elseif(trigger == "!help" ) then		-- THEY WANT HELP / LIST OF COMMANDS
			WebDKP_SendWhisper(name,"Available Commands:"); 
			WebDKP_SendWhisper(name,"!dkp - Get your current dkp");
			WebDKP_SendWhisper(name,"!list - List dkp of group");
			WebDKP_SendWhisper(name,"!listall - List dkp of guild (BIG)");   
			WebDKP_SendWhisper(name,"!help - This menu"); 
			WebDKP_SendWhisper(name,"Limit lists by appending class names after them."); 
			WebDKP_SendWhisper(name,"Example: '!list hunter' will only list hunters"); 
			WebDKP_SendWhisper(name,"Example: '!list hunter rogue' will only list hunters and rogues"); 
		end
	end
end

-- ================================
-- Our special event hook that picks up on all whispers 
-- Before they are displayed on the screen or trigger the 
-- regular whisper. Here we can hide any whispers that our
-- ours. 
-- ================================
function WebDKP_ChatFrame_OnEvent_Hook()
    if ( arg1 and arg2 ) then
        -- whisper too me
        if ( event == "CHAT_MSG_WHISPER" ) then
            if ( WebDKP_IsWebDKPWhisper( arg2, arg1 ) ) then
                -- don't display whispercast whisper
                return
            end
        end
        -- whisper I am sending
        if ( event == "CHAT_MSG_WHISPER_INFORM" ) then
            if ( string.find(arg1,"^WebDKP: " ) ) then
                -- hide whispers that I am sending
                return
            end
        end
    end
    
    WebDKP_ChatFrame_OnEvent_Original(event, arg1, name);
end

-- ================================
-- Returns true if the passed whisper is a whisper directed
-- towards web dkp
-- ================================
function WebDKP_IsWebDKPWhisper(name, trigger)
	-- if it has webdkp in it, its an outgoing message. ignore it
	if ( string.find(string.lower(trigger), "WebDKP:" ) ) then
		return false;
	end
	if ( string.find(string.lower(trigger), "!dkp" )==1 or
		 string.find(string.lower(trigger), "!help")==1 or
		 string.find(string.lower(trigger), "!list")==1
		) then
        return true
    end
    
    return false
end

-- ================================
-- For whisper event hook - sends a whisper back
-- to the given person with a webdkp header so it 
-- will not be displayed in regular whisper chat
-- ================================
function WebDKP_SendWhisper(toPlayer, message)
	SendChatMessage("WebDKP: "..message, "WHISPER", nil, toPlayer)
end
---------------------------------------------------
-- GUI EVENT HANDLERS
---------------------------------------------------
-- ================================
-- Called by the refresh button. Refreshes the people displayed 
-- in your party. 
-- ================================
function WebDKP_Refresh()
	WebDKP_UpdatePlayersInGroup();
	WebDKP_UpdateTableToShow();
	WebDKP_UpdateTable();
end

-- ================================
-- Called when a player clicks on different tabs. 
-- Causes certain frames to be hidden and the appropriate
-- frame to be displayed
-- ================================
function WebDKP_Tab_OnClick()
	if ( this:GetID() == 1 ) then
		getglobal("WebDKP_FiltersFrame"):Show();
		getglobal("WebDKP_AwardDKP_Frame"):Hide();
		getglobal("WebDKP_AwardItem_Frame"):Hide();
	elseif ( this:GetID() == 2 ) then
		getglobal("WebDKP_FiltersFrame"):Hide();
		getglobal("WebDKP_AwardDKP_Frame"):Show();
		getglobal("WebDKP_AwardItem_Frame"):Hide();
	elseif (this:GetID() == 3 ) then
		getglobal("WebDKP_FiltersFrame"):Hide();
		getglobal("WebDKP_AwardDKP_Frame"):Hide();
		getglobal("WebDKP_AwardItem_Frame"):Show();
	end 
	PlaySound("igCharacterInfoTab");
end

-- ================================
-- Called when a player clicks on a column header on the table
-- Changes the sorting options / asc&desc. 
-- Causes the table display to be refreshed afterwards
-- to player instantly sees changes
-- ================================
function WebDPK2_SortBy(id)
	if ( WebDKP_LogSort["curr"] == id ) then
		WebDKP_LogSort["way"] = abs(WebDKP_LogSort["way"]-1);
	else
		WebDKP_LogSort["curr"] = id;
		if( id == 1) then
			WebDKP_LogSort["way"] = 0;
		elseif ( id == 2 ) then
			WebDKP_LogSort["way"] = 0;
		elseif ( id == 3 ) then
			WebDKP_LogSort["way"] = 1; --columns with numbers need to be sorted different first in order to get DESC right
		else
			WebDKP_LogSort["way"] = 1; --columns with numbers need to be sorted different first in order to get DESC right
		end
		
	end
	-- update table so we can see sorting changes
	WebDKP_UpdateTable();
end

-- ================================
-- Called when the user clicks on a filter checkbox. 
-- Changes the filter setting and updates table
-- ================================
function WebDKP_ToggleFilter(filterName)
	WebDKP_Filters[filterName] = abs(WebDKP_Filters[filterName]-1);
	WebDKP_UpdateTableToShow();
	WebDKP_UpdateTable();
end

-- ================================
-- Called when user clicks on 'check all'
-- Sets all filters to on and updates table display
-- ================================
function WebDKP_CheckAllFilters()
	WebDKP_SetFilterState("Druid",1);
	WebDKP_SetFilterState("Hunter",1);
	WebDKP_SetFilterState("Mage",1);
	WebDKP_SetFilterState("Rogue",1);
	WebDKP_SetFilterState("Shaman",1);
	WebDKP_SetFilterState("Paladin",1);
	WebDKP_SetFilterState("Priest",1);
	WebDKP_SetFilterState("Warrior",1);
	WebDKP_SetFilterState("Warlock",1);
	WebDKP_UpdateTableToShow();
	WebDKP_UpdateTable();
end

-- ================================
-- Called when user clicks on 'uncheck all'
-- Sets all filters to off and updates table display
-- ================================
function WebDKP_UncheckAllFilters()
	WebDKP_SetFilterState("Druid",0);
	WebDKP_SetFilterState("Hunter",0);
	WebDKP_SetFilterState("Mage",0);
	WebDKP_SetFilterState("Rogue",0);
	WebDKP_SetFilterState("Shaman",0);
	WebDKP_SetFilterState("Paladin",0);
	WebDKP_SetFilterState("Priest",0);
	WebDKP_SetFilterState("Warrior",0);
	WebDKP_SetFilterState("Warlock",0);
	WebDKP_UpdateTableToShow();
	WebDKP_UpdateTable();
end

-- ================================
-- Small helper method for filters - updates
-- checkbox state and updates filter setting in data structure
-- ================================
function WebDKP_SetFilterState(filter,newState)
	local checkBox = getglobal("WebDKP_FiltersFrameClass"..filter);
	checkBox:SetChecked(newState);
	WebDKP_Filters[filter] = newState;
end

-- ================================
-- Called when mouse goes over a dkp line entry. 
-- If that player is not selected causes that row
-- to become 'highlighted'
-- ================================
function WebDKP_HandleMouseOver()
	local playerName = getglobal(this:GetName().."Name"):GetText();
	if( not WebDKP_DkpTable[playerName]["Selected"] ) then
		getglobal(this:GetName() .. "Background"):SetVertexColor(0.2, 0.2, 0.7, 0.5);
	end
end

-- ================================
-- Called when a mouse leaes a dkp line entry. 
-- If that player is not selected, causes that row
-- to return to normal (none highlighted)
-- ================================
function WebDKP_HandleMouseLeave()
	local playerName = getglobal(this:GetName().."Name"):GetText();
	if( not WebDKP_DkpTable[playerName]["Selected"] ) then
		getglobal(this:GetName() .. "Background"):SetVertexColor(0, 0, 0, 0);
	end
end

-- ================================
-- Called when the user clicks on a player entry. Causes 
-- that entry to either become selected or normal
-- and updates the dkp table with the change
-- ================================
function WebDKP_SelectPlayerToggle()
	local playerName = getglobal(this:GetName().."Name"):GetText();
	if( WebDKP_DkpTable[playerName]["Selected"] ) then
		WebDKP_DkpTable[playerName]["Selected"] = false;
		getglobal(this:GetName() .. "Background"):SetVertexColor(0.2, 0.2, 0.7, 0.5);
	else
		WebDKP_DkpTable[playerName]["Selected"] = true;
		getglobal(this:GetName() .. "Background"):SetVertexColor(0.1, 0.1, 0.9, 0.8);
	end
end

-- ================================
-- Selects all players in the dkp table and updates 
-- table display
-- ================================
function WebDKP_SelectAll()
	local tableid = WebDKP_GetTableid();
	for k, v in WebDKP_DkpTable do
		if ( type(v) == "table" ) then
			local playerName = k; 
			local playerClass = v["class"];
			local playerDkp = v["dkp"..tableid];
			if ( playerDkp == nil ) then 
				v["dkp"..tableid] = 0;
				playerDkp = 0;
			end
			local playerTier = floor((playerDkp-1)/WebDKP_TierInterval);
			if (WebDKP_ShouldDisplay(playerName, playerClass, playerDkp, playerTier)) then
				WebDKP_DkpTable[playerName]["Selected"] = true;
			else
				WebDKP_DkpTable[playerName]["Selected"] = false;
			end
		end
	end
	WebDKP_UpdateTable();
end

-- ================================
-- Deselect all players and update table display
-- ================================
function WebDKP_UnselectAll()
	for k, v in WebDKP_DkpTable do
		if ( type(v) == "table" ) then
			local playerName = k; 
			WebDKP_DkpTable[playerName]["Selected"] = false;
		end
	end
	WebDKP_UpdateTable();
end



-- ================================
-- Called when user clicks on the 'award item' box. 
-- Gets the first selected player in the list, and the
-- contents of the award item edit boxes. Uses this to 
-- display a short blirb to the screen then recordes 
-- the changes
-- ================================
function WebDKP_AwardItem_Event()
	local name, class, guild;
	local cost = WebDKP_AwardItem_FrameItemCost:GetText();
	local item = WebDKP_AwardItem_FrameItemName:GetText();
	local points = cost * -1;
	name = WebDKP_GetFirstSelectedPlayer();
	if(name == "NONE") then
		WebDKP_Print("You must select a player to award the item to");
		return; 
	end
	guild = WebDKP_GetGuildName(name);
	class = WebDKP_DkpTable[name]["class"];
	local tellLocation = WebDKP_GetTellLocation();
	if(not (tellLocation == "NONE") ) then
		SendChatMessage("WebDKP Item Award Notice",tellLocation);
		SendChatMessage("=============================",tellLocation);
		SendChatMessage("Item Awarded: "..item,tellLocation);
		SendChatMessage("Who: "..name,tellLocation);
		SendChatMessage("Cost: "..cost,tellLocation);
	else
		WebDKP_Print(item.." awarded to "..name.." for "..cost.." dkp.");
	end
	local forItem = "true";
	WebDKP_AddDKP2(name,guid,class,points,item,forItem);
	
	-- Update the table so we can see the new dkp status
	WebDKP_UpdateTableToShow();
	WebDKP_UpdateTable();
	
end

-- ================================
-- Called when user clicks on 'award dkp' on the award 
-- dkp tab. Gets data from the award dkp edit boxes. 
-- Uses this to display a little blirb, then recodes
-- this information for all players currently selected
-- (note, if player is hidden due to filter, they are automattically
-- deselected)
-- ================================
function WebDKP_AwardDKP_Event()
	local name, class, guild;
	local points = WebDKP_AwardDKP_FramePoints:GetText();
	local reason = WebDKP_AwardDKP_FrameReason:GetText();
	local allGroupSelected = WebDKP_AllGroupSelected();
	local tellLocation = WebDKP_GetTellLocation();
	if(not (tellLocation == "NONE") ) then
		SendChatMessage("WebDKP Award Notice",tellLocation);
		SendChatMessage("=============================",tellLocation);
		SendChatMessage("Reason: "..reason,tellLocation);
		-- if all players selected display 'all players', otherwise, list all players being awarded
		if (allGroupSelected==true) then
			SendChatMessage("Awarding "..points.." points to all players in group.",tellLocation);
		else
			SendChatMessage("Awarding "..points.." points to the following players.",tellLocation);
		end
	else
		WebDKP_Print("Awarding "..points.." dkp for: "..reason);
		if (allGroupSelected==true) then
			WebDKP_Print("Awarded to entire group.");
		else
			WebDKP_Print("Awarded to following players:");
		end
		
	end
	-- go ahead and award all the points
	for k, v in WebDKP_DkpTable do
		if ( type(v) == "table" ) then
			if( v["Selected"] ) then
				name = k; 
				class = v["class"];
				guild = WebDKP_GetGuildName(name);
				if(not (tellLocation == "NONE") and not allGroupSelected) then
					SendChatMessage(name,tellLocation);
				elseif(not allGroupSelected) then
					WebDKP_Print(name);
				end
				WebDKP_AddDKP2(name,guid,class,points,reason,false);
			end
		end
	end
	
	-- Update the table so we can see the new dkp status
	WebDKP_UpdateTableToShow();
	WebDKP_UpdateTable();
end


function WebDKP_Tables_DropDown_OnLoad()
	UIDropDownMenu_Initialize(WebDKP_Tables_DropDown, WebDKP_Tables_DropDown_Init);
	
	local numTables = WebDKP_GetTableSize(WebDKP_Tables)
	if ( WebDKP_Tables == nil or numTables==0 or numTables==1) then
		WebDKP_Tables_DropDown:Hide();
	else
		WebDKP_Tables_DropDown:Show();
	end
end

function WebDKP_Tables_DropDown_Init()
	if( WebDKP_Frame.selectedTableid == nil ) then
		WebDKP_Frame.selectedTableid = 1;
	end
	local info;
	local selected = "";
	if ( WebDKP_Tables ~= nil and next(WebDKP_Tables)~=nil ) then
		for key, entry in WebDKP_Tables do
			if ( type(entry) == "table" ) then
				info = { };
				info.text = key;
				info.value = entry["id"];
				info.func = WebDKP_Tables_DropDown_OnClick;
				if ( entry["id"] == WebDKP_Frame.selectedTableid ) then
					info.checked = ( entry["id"] == WebDKP_Frame.selectedTableid );
					selected = info.text;
				end
				UIDropDownMenu_AddButton(info);
			end
		end
	end
	UIDropDownMenu_SetSelectedName(WebDKP_Tables_DropDown, selected );
	UIDropDownMenu_SetWidth(200, WebDKP_Tables_DropDown);
end

function WebDKP_Tables_DropDown_OnClick()
	WebDKP_Frame.selectedTableid = this.value; 
	WebDKP_Tables_DropDown_Init();
	WebDKP_UpdateTableToShow();
	WebDKP_UpdateTable();
end

function WebDKP_GetTableSize(table)
	local count = 0;
	if( table == nil ) then
		return count;
	end
	for key, entry in table do
		count = count + 1;
	end
	return count;

end

---------------------------------------------------
-- AWARD METHODS (award dkp)
---------------------------------------------------

-- ================================
-- Adds dkp to the specified user with the given properties. 
-- This writes the data first to a simple 'user'->'dkp' data structure
-- then calls another method to store the data in the log file
-- ================================
function WebDKP_AddDKP2(name,guild,class,points, reason, forItem)
	--First, add their guild to the straight up listings in memory.
	--This is just a plain UserName - DKP list
	
	local tableid = WebDKP_GetTableid();

	--make sure the user entry in the list exists. If not, create it
	if (not WebDKP_DkpTable[name]) then
		WebDKP_DkpTable[name] = {};
		WebDKP_DkpTable[name]["dkp_"..tableid] = 0;
	end
	if (WebDKP_DkpTable[name]["dkp_"..tableid] == nil) then
		WebDKP_DkpTable[name]["dkp_"..tableid] = 0;
	end
	--now add the dkp
	WebDKP_DkpTable[name]["dkp_"..tableid] = WebDKP_DkpTable[name]["dkp_"..tableid] + points;
	
	--Now we need to append them to the log that will be uploaded to the site
	WebDKP_AppendToLog(name, guild ,class, points, reason,forItem)
end

-- ================================
-- Appends the current information to the dkp log file
-- This is the variable that will eventually be saved
-- to a file and uploaded to the site
-- ================================
function WebDKP_AppendToLog(name,guild,class,points,reason,forItem)
	if(forItem == nil) then
		forItem = "false";
	end
	
	--first, make sure the dkp log exists
	if (not WebDKP_Log) then
		WebDKP_Log = {};
	end
	--next, make sure this player is in the log
	if (not WebDKP_Log[name]) then
		WebDKP_Log[name] = {};
		--also create an (info) entry that will keep track of how many log entries there
		--are for this player
		WebDKP_Log[name]["info"] = {
			["count"] = 0;
		}
	end

	local tableid = WebDKP_GetTableid();
	
	--get the current count of log entries for this player. 
	--this will be used to determine the next log count
	local newLogNumber = WebDKP_Log[name]["info"]["count"] +1;
	WebDKP_Log[name]["info"]["count"] = newLogNumber;
	
	--get the current time and zone that will be used to label 
	--this entry in the log
	local currentTime  = date("%Y-%m-%d %H:%M:%S");
	local zone = GetZoneText();

	--now make the entry to the log
	WebDKP_Log[name][newLogNumber] = {
		["name"] = name,
		["guild"] = guild,
		["class"] = class,
		["points"] = points,
		["reason"] = reason,
		["zone"] = zone,
		["awardedby"] = UnitName("player"),
		["date"] = currentTime,
		["foritem"] = forItem,
		["tableid"] = tableid
	};
end



---------------------------------------------------
-- TABLE DISPLAY METHODS
---------------------------------------------------
-- ================================
-- Rerenders the table to the screen. This is called 
-- on a few instances - when the scroll frame throws an 
-- event or when filters are applied or when group
-- memebers change. 
-- General structure:
-- First runs through the table to display and puts the data
-- into a temp array to work with
-- Then uses sorting options to sort the temp array
-- Calculates the offset of the table to determine
-- what information needs to be displayed and in what lines 
-- of the table it should be displayed
-- ================================
function WebDKP_UpdateTable()
	--self:Print("Scroll method called");
	-- Copy data to the temporary array
	local entries = { };
	for k, v in WebDKP_DkpTableToShow do
		if ( type(v) == "table" ) then
			if( v[1] ~= nil and v[2] ~= nil and v[3] ~=nil and v[4] ~=nil) then
				tinsert(entries,{v[1],v[2],v[3],v[4]}); -- copies over name, class, dkp, tier
			end
		end
	end
	
	-- SORT
	table.sort(
		entries,
		function(a1, a2)
			if ( a1 and a2 ) then
				if ( a1 == nil ) then
					return 1>0;
				elseif (a2 == nil) then
					return 1<0;
				end
				if ( WebDKP_LogSort["way"] == 1 ) then
					if ( a1[WebDKP_LogSort["curr"]] == a2[WebDKP_LogSort["curr"]] ) then
						return a1[1] > a2[1];
					else
						return a1[WebDKP_LogSort["curr"]] > a2[WebDKP_LogSort["curr"]];
					end
				else
					if ( a1[WebDKP_LogSort["curr"]] == a2[WebDKP_LogSort["curr"]] ) then
						return a1[1] < a2[1];
					else
						return a1[WebDKP_LogSort["curr"]] < a2[WebDKP_LogSort["curr"]];
					end
				end
			end
		end
	);
	
	local numEntries = getn(entries);
	local offset = FauxScrollFrame_GetOffset(WebDKP_FrameScrollFrame);
	FauxScrollFrame_Update(WebDKP_FrameScrollFrame, numEntries, 20, 20);
	
	-- Run through the table lines and put the appropriate information into each line
	for i=1, 20, 1 do
		local line = getglobal("WebDKP_FrameLine" .. i);
		local nameText = getglobal("WebDKP_FrameLine" .. i .. "Name");
		local classText = getglobal("WebDKP_FrameLine" .. i .. "Class");
		local dkpText = getglobal("WebDKP_FrameLine" .. i .. "DKP");
		local tierText = getglobal("WebDKP_FrameLine" .. i .. "Tier");
		local index = i + FauxScrollFrame_GetOffset(WebDKP_FrameScrollFrame); 
		
		if ( index <= numEntries) then
			local playerName = entries[index][1];
			line:Show();
			nameText:SetText(entries[index][1]);
			classText:SetText(entries[index][2]);
			dkpText:SetText(entries[index][3]);
			tierText:SetText(entries[index][4]);
			-- kill the background of this line if it is not selected
			if( not WebDKP_DkpTable[playerName]["Selected"] ) then
				getglobal("WebDKP_FrameLine" .. i .. "Background"):SetVertexColor(0, 0, 0, 0);
			else
				getglobal("WebDKP_FrameLine" .. i .. "Background"):SetVertexColor(0.1, 0.1, 0.9, 0.8);
			end
		else
			-- if the line isn't in use, hide it so we dont' have mouse overs
			line:Hide();
		end
	end
end


-- ================================
-- Helper method that determines the table that should be shown. 
-- This runs through the dkp list and checks filters against each entry
-- If an entry passes it is moved to the table to show. If it doesn't pass
-- the test it is ignored. 
-- ================================
function WebDKP_UpdateTableToShow()
	local tableid = WebDKP_GetTableid();
	-- clear the old table
	WebDKP_DkpTableToShow = { };
	-- increment through the dkp table and move data over
	for k, v in WebDKP_DkpTable do
		if ( type(v) == "table" ) then
			local playerName = k; 
			local playerClass = v["class"];
			local playerDkp = v["dkp_"..tableid];
			if ( playerDkp == nil ) then 
				v["dkp"..tableid] = 0;
				playerDkp = 0;
			end
			local playerTier = floor((playerDkp-1)/WebDKP_TierInterval);
			if( playerDkp == 0 ) then
				playerTier = 0;
			end
			-- if it should be displayed (passes filter) add it to the table
			if (WebDKP_ShouldDisplay(playerName, playerClass, playerDkp, playerTier)) then
				tinsert(WebDKP_DkpTableToShow,{playerName,playerClass,playerDkp,playerTier});
			else
				-- if it is not displayed, deselect it automattically for us
				WebDKP_DkpTable[playerName]["Selected"] = false;
			end
		end
	end
	-- now need to run through anyone else who is in our current raid / party
	-- They may not have dkp yet and may not be in our dkp table. Use this oppurtunity 
	-- to add them to the table with 0 points and add them to the to display table if appropriate
	-- table to be displayed
	for key, entry in WebDKP_PlayersInGroup do
		if ( type(entry) == "table" ) then
			local playerName = entry["name"];
			-- is this a new person we havn't seen before?
			if ( WebDKP_DkpTable[playerName] == nil) then
				-- new person, they need to be added
				local playerClass = entry["class"];
				local playerDkp = 0;
				local playerTier = 0;
				-- go ahead and add them to our dkp table now, for future reference
				if( not (playerName == nil) ) then
					WebDKP_DkpTable[playerName] = {
						["dkp_"..tableid] = 0,
						["class"] = playerClass,
					}
				end
				-- do a final check to see if we should display (pass all filters, etc.)
				if (WebDKP_ShouldDisplay(playerName, playerClass, playerDkp, playerTier)) then
					tinsert(WebDKP_DkpTableToShow,{playerName,playerClass,playerDkp,playerTier});
				else
					WebDKP_DkpTable[playerName]["Selected"] = false;
				end
			end
		end
	end
end

function WebDKP_GetTableid()
	local tableid = WebDKP_Frame.selectedTableid;
	if (tableid == nil ) then
		tableid = 1;
	end
	return tableid;
end


-- ================================
-- Helper method. Returns true if the current player should be displayed
-- on the table by checking it against current filters
-- ================================
function WebDKP_ShouldDisplay(name, class, dkp, tier)
	if (name == "Unknown") then
		return false;
	end
	if (WebDKP_Filters[class] == 0) then
		return false;
	end 
	if (WebDKP_Filters["Group"] == 1 and WebDKP_PlayerInGroup(name) == false) then
		return false
	end
	return true; 
end


-- ================================
-- Helper method for should display. Returns true if the specified player
-- is in the current group
-- ================================
function WebDKP_PlayerInGroup(name)
	for key, entry in WebDKP_PlayersInGroup do
		if ( type(entry) == "table" ) then
			if ( entry["name"] == name) then
				return true;
			end
		end
	end
	return false;
end

---------------------------------------------------
-- ADDITIONAL UTILITY METHODS
---------------------------------------------------


-- ================================
-- Updates the list of players in our current group.
-- First attempts to get raid data. If user isn't in a raid
-- it checks party data. If user is not in a party there 
-- is no information to get
-- ================================
function WebDKP_UpdatePlayersInGroup()
	-- Updates the list of players currently in the group
	-- First attempts to get this data via a query to the raid. 
	-- If that failes it resorts to querying for party data
	local numberInRaid = GetNumRaidMembers();
	local numberInParty = GetNumPartyMembers();
	WebDKP_PlayersInGroup = {};
	-- Is a raid going?
	if ( numberInRaid > 0 ) then
		-- Yes! Load raid data...
		local name, class, guild;
		for i=1, numberInRaid do
			name, _, _, _, class, _, _, _ , _ = GetRaidRosterInfo(i);
			WebDKP_PlayersInGroup[i]=
			{
				["name"] = name,
				["class"] = class,
			};
		end
	-- Is a party going?
	elseif ( numberInRaid == 0 and numberInParty>0) then
		-- Yes! Load party data instead...
		local name, class, guild, playerHandle;
		for i=1, numberInParty do
			playerHandle = "party"..i;
			name = UnitName(playerHandle);
			class = UnitClass(playerHandle);
			WebDKP_PlayersInGroup[i]=
			{
				["name"] = name,
				["class"] = class,
			};
		end
		-- this doesn't load the current player, so we need to add them manually
		WebDKP_PlayersInGroup[numberInParty+1]=
		{
			["name"] = UnitName("player"),
			["class"] = UnitClass("player"),
		};
	end
	-- not in party or raid, don't need to load anything special
end



-- ================================
-- Returns the guild name of a specified player. This attempts this
-- in a few ways. First tries to get it via raid data. If not in a raid
-- it attempts to get it via party data. If all these fail, it returns
-- "Unknown" which is a marker for the webdkp.com site to try to get
-- the real guild name sometime in the future. 
-- ================================
function WebDKP_GetGuildName(playerName)
	-- this is a big pain - we can't just query a player for a guild, 
	-- we need to find their slot in the current raid / party and query
	-- that slot...
	
	-- First try running through all the people in the current raid...
	local numberInRaid = GetNumRaidMembers();
	local name, class;
	for i=1, numberInRaid do
		name, _, _, _, _, _, _, _ , _ = GetRaidRosterInfo(i);
		if ( name == playerName) then
			guild, _, _ = GetGuildInfo("raid"..i);
			return guild;
		end
	end
	
	-- No go, now try running through people in the current party --
	local numberInParty = GetNumPartyMembers();
	for i=1, numberInParty do
		playerHandle = "party"..i;
		name = UnitName(playerHandle);
		if( name == playerName ) then
			guild, _, _ = GetGuildInfo("raid"..i);
			return guild;
		end
	end
	
	-- no go, try the current player
	if( playerName == UnitName("player") ) then
		guild, _, _ = GetGuildInfo("player");
		return guild;
	end
	
	-- all failed, return unknown
	return "Unknown";

end

-- ================================
-- Returns true if everyone in the current group is selected. 
-- This is a helper method when displaying messages to chat. 
-- If everyone is selected you can just say "awarded points to everyone"
-- versus listing out everyone who was selected invidiually
-- ================================
function WebDKP_AllGroupSelected()
	-- First try running through the raid and see if they are all selected
	local name, class;
	local numberInRaid = GetNumRaidMembers();
	local numberInParty = GetNumPartyMembers();
	if(numberInRaid > 0 ) then
		for i=1, numberInRaid do
			name, _, _, _, _, _, _, _ , _ = GetRaidRosterInfo(i);
			if ( not WebDKP_DkpTable[name]["Selected"]) then
				return false;
			end
		end
		return true;
	elseif ( numberInParty > 0) then
		for i=1, numberInParty do
			playerHandle = "party"..i;
			name = UnitName(playerHandle);
			if ( not WebDKP_DkpTable[name]["Selected"]) then
				return false;
			end
		end
		--before we return true we also need to check the current player...
		if ( not WebDKP_DkpTable[UnitName("player")]["Selected"]) then
			return false;
		end
		return true;
	end
	-- entire group isn't selected, do things manually
	return false;
end

-- ================================
-- Returns the location where notifications should be sent to. 
-- "Raid" or "Party". If player is in neither a raid or a party, returns
-- "None"
-- ================================
function WebDKP_GetTellLocation()
	local numberInRaid = GetNumRaidMembers();
	local numberInParty = GetNumPartyMembers();
	if( numberInRaid > 0 ) then
		return "RAID";
	elseif (numberInParty > 0 ) then
		return "PARTY";
	else
		return "NONE";
	end
end

-- ================================
-- Helper method for awarding an item. 
-- Returns the name of the first selected player
-- If no one is selected returns 'NONE'
-- ================================
function WebDKP_GetFirstSelectedPlayer()
	for k, v in WebDKP_DkpTable do
		if ( type(v) == "table" ) then
			if( v["Selected"] ) then
				name = k; 
				return name;
			end
		end
	end
	return "NONE";
end

-- ================================
-- Helper method for the whisper features. 
-- Sends the player a list of dkp for people either in the current
-- group or in the guild
-- ================================
function WebDKP_WhisperSortedList(toPlayer, limitToGroup, classFilter)
	local tableid = WebDKP_GetTableid();	
	if(classFilter == nil) then
		classFilter = {};
	end
	-- increment through the dkp table and move data over
	local tableToWhisper={}; 
	for k, v in WebDKP_DkpTable do
		if ( type(v) == "table" ) then
			local playerName = k; 
			local playerClass = v["class"];
			local playerDkp = v["dkp_"..tableid];
			if ( playerDkp ~= nil ) then
				local playerTier = floor((playerDkp-1)/WebDKP_TierInterval);
				if( playerDkp == 0 ) then
					playerTier = 0;
				end
				-- if it should be displayed (passes filter) add it to the table
				if (WebDKP_PassesWhisperFilter(playerName, playerClass, playerDkp, playerTier,limitToGroup,classFilter)) then
					tinsert(tableToWhisper,{playerName,playerClass,playerDkp,playerTier});
				end
			end
		end
	end
	-- we now have our table to whisper
	-- sort it
	table.sort(
		tableToWhisper,
		function(a1, a2)
			if ( a1 and a2 ) then
				if(a1[3] == a2[3]) then
					return a1[1] >= a2[1];
				else
					return a1[3] <= a2[3];
				end
			end
		end
	);
	
	-- display it
	for k, v in tableToWhisper do
		if ( type(v) == "table" ) then
			if( v[1] ~= nil and v[2] ~= nil and v[3] ~= nil) then
				WebDKP_SendWhisper(toPlayer,v[3].." - Tier "..v[4].." "..v[1].." ( "..v[2].." ) "); 
			end
		end
	end
end

-- ================================
-- Checks to see if a given entry passes a set of whisper filters
-- ================================
function WebDKP_PassesWhisperFilter(name, class, dkp, tier, limitToGroup, filter)
	-- check the limit to group
	if( limitToGroup ) then
		if( not WebDKP_PlayerInGroup(name) ) then
			return false;
		end
	end
	-- now check the filters
	if ( filter["showall"] ) then
		return true;
	else
		-- return true if the class entry is not equal to nil, meaning it should be displayed
		if( class == nil) then
			return false;
		end
		return (not ( filter[string.lower(class)] == nil ) ); 
	end
	
	
end

-- ================================
-- Scans a whisper message to determine what filters are being used. 
-- Returns a filter object that can be passed to WebDKP_WhisperSortedList
-- ================================
function WebDKP_GetWhisperFiltersFromMessage(message)
	local filter = {}; 
	filter["druid"] = string.find(string.lower(message), "druid");
	filter["hunter"] = string.find(string.lower(message), "hunter");
	filter["mage"]= string.find(string.lower(message), "mage");
	filter["rogue"] = string.find(string.lower(message), "rogue");
	filter["shaman"] = string.find(string.lower(message), "shaman");
	filter["paladin"] = string.find(string.lower(message), "paladin");
	filter["priest"] = string.find(string.lower(message), "priest");
	filter["warrior"] = string.find(string.lower(message), "warrior");
	filter["warlock"] = string.find(string.lower(message), "warlock");
	
	-- If no filters were passed, everything should be nill. In that case
	-- just display everyone
	if( filter["druid"] == nil and filter["hunter"] == nil and filter["mage"] == nil and
		filter["rogue"] == nil and filter["shaman"] == nil and filter["paladin"] == nil  and
		filter["priest"] == nil and filter["warrior"] == nil  and filter["warlock"] == nil  ) then
		filter["showall"] = true;
	else
		filter["showall"] = false;
	end
	return filter;
end

-- ================================
-- Prints a message to the console. Used for debugging
-- ================================
function WebDKP_Print(toPrint)
	DEFAULT_CHAT_FRAME:AddMessage(toPrint, 1, 1, 0);
end






-- Notes to self for future code:
-- this:RegisterEvent("CHAT_MSG_WHISPER");



-- Create some sample data to play with
WebDKP_DkpTable_Ignore = {
	["A"] = {
		["dkp"] = 55,
		["class"] = "Shaman",
	},
	["B"] = {
		["dkp"] = 12,
		["class"] = "Paladin",
	},
	["C"] = {
		["dkp"] = 222,
		["class"] = "Rogue",
	},
	["D"] = {
		["dkp"] = 315,
		["class"] = "Rogue",
	},
	["E"] = {
		["dkp"] = 70,
		["class"] = "Druid",
	},
	["F"] = {
		["dkp"] = 100,
		["class"] = "Hunter",
	},
	["G"] = {
		["dkp"] = 101,
		["class"] = "Rogue",
	},
	["H"] = {
		["dkp"] = 120,
		["class"] = "Paladin",
	},
	["I"] = {
		["dkp"] = 160,
		["class"] = "Rogue",
	},
	["J"] = {
		["dkp"] = 290,
		["class"] = "Mage",
	},
	["K"] = {
		["dkp"] = 500,
		["class"] = "Priest",
	},
	["L"] = {
		["dkp"] = 70,
		["class"] = "Warrior",
	},
	["M"] = {
		["dkp"] = 90,
		["class"] = "Hunter",
	},
	["N"] = {
		["dkp"] = 596,
		["class"] = "Paladin",
	},
	["O"] = {
		["dkp"] = 350,
		["class"] = "Shaman",
	},
	["P"] = {
		["dkp"] = 35,
		["class"] = "Priest",
	},
	["Q"] = {
		["dkp"] = 246,
		["class"] = "Druid",
	},
	["R"] = {
		["dkp"] = 126,
		["class"] = "Mage",
	},
	["S"] = {
		["dkp"] = 127,
		["class"] = "Hunter",
	},
	["T"] = {
		["dkp"] = 438,
		["class"] = "Warlock",
	},
	["U"] = {
		["dkp"] = 13,
		["class"] = "Warrior",
	},
	["V"] = {
		["dkp"] = 421,
		["class"] = "Druid",
	},
	["W"] = {
		["dkp"] = 346,
		["class"] = "Shaman",
	},
	["X"] = {
		["dkp"] = 623,
		["class"] = "Warlock",
	},
	["Y"] = {
		["dkp"] = 84,
		["class"] = "Mage",
	},
	["Z"] = {
		["dkp"] = 32,
		["class"] = "Hunter",
	},
};