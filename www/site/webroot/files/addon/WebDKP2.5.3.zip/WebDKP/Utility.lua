------------------------------------------------------------------------
-- UTILITY
------------------------------------------------------------------------
-- This file contains utility methods used by the rest of thea ddon
------------------------------------------------------------------------

-- ================================
-- Helper method. Returns the id of the currently
-- selected table (if working with multiple dkp tables)
-- ================================
function WebDKP_GetTableid()
	local tableid = WebDKP_Frame.selectedTableid;
	if (tableid == nil ) then
		tableid = 1;
	end
	return tableid;
end





-- ================================
-- Helper method for should display. Returns true if the specified player
-- is in the current group
-- ================================
function WebDKP_PlayerInGroup(name)
	for key, entry in WebDKP_PlayersInGroup do
		if ( type(entry) == "table" ) then
			if ( entry["name"] == name) then
				return true;
			end
		end
	end
	return false;
end


-- ================================
-- Returns the guild name of a specified player. This attempts this
-- in a few ways. First tries to get it via raid data. If not in a raid
-- it attempts to get it via party data. If all these fail, it returns
-- "Unknown" which is a marker for the webdkp.com site to try to get
-- the real guild name sometime in the future. 
-- ================================
function WebDKP_GetGuildName(playerName)
	-- this is a big pain - we can't just query a player for a guild, 
	-- we need to find their slot in the current raid / party and query
	-- that slot...
	
	-- First try running through all the people in the current raid...
	local numberInRaid = GetNumRaidMembers();
	local name, class;
	for i=1, numberInRaid do
		name, _, _, _, _, _, _, _ , _ = GetRaidRosterInfo(i);
		if ( name == playerName) then
			guild, _, _ = GetGuildInfo("raid"..i);
			return guild;
		end
	end
	
	-- No go, now try running through people in the current party --
	local numberInParty = GetNumPartyMembers();
	for i=1, numberInParty do
		playerHandle = "party"..i;
		name = UnitName(playerHandle);
		if( name == playerName ) then
			guild, _, _ = GetGuildInfo("raid"..i);
			return guild;
		end
	end
	
	-- no go, try the current player
	if( playerName == UnitName("player") ) then
		guild, _, _ = GetGuildInfo("player");
		return guild;
	end
	
	-- all failed, return unknown
	return "Unknown";

end

-- ================================
-- Helper method for awarding an item. 
-- Returns the name of the first selected player
-- If no one is selected returns 'NONE'
-- ================================
function WebDKP_GetFirstSelectedPlayer()
	for k, v in WebDKP_DkpTable do
		if ( type(v) == "table" ) then
			if( v["Selected"] ) then
				name = k; 
				return name;
			end
		end
	end
	return "NONE";
end

-- ================================
-- Helper method. Returns the size
-- of the passed table. Returns 0 if
-- the passed variable is nil.
-- ================================
function WebDKP_GetTableSize(table)
	local count = 0;
	if( table == nil ) then
		return count;
	end
	for key, entry in table do
		count = count + 1;
	end
	return count;
end

-- ================================
-- Prints a message to the console. Used for debugging
-- ================================
function WebDKP_Print(toPrint)
	DEFAULT_CHAT_FRAME:AddMessage(toPrint, 1, 1, 0);
end


function WebDKP_GetItemInfo(sItem)
	-- Thanks to Telo for the following regular expression
	local iStart, iEnd, sColor, sItemName, sName = string.find(sItem, "|c(%x+)|Hitem:(%d+:%d+:%d+:%d+)|h%[(.-)%]|h|r");
	if ( sColor and sItemName and sName ) then
		return sColor, sItemName, sName;
	end
end

function WebDKP_SelectPlayerOnly(toHighlight)
	for k, v in WebDKP_DkpTable do
		if ( type(v) == "table" ) then
			local playerName = k;
			if ( playerName == toHighlight ) then
				WebDKP_DkpTable[playerName]["Selected"] = true;
			else
				WebDKP_DkpTable[playerName]["Selected"] = false;
			end
		end
	end
	-- If the player is not currently shown in the table, add them (otherwise we can't see if they are highlighted)
	if( WebDKP_PlayerIsShown(toHighlight) == 0 ) then
		WebDKP_ShowPlayer(toHighlight);
	end
	WebDKP_UpdateTable();
end

function WebDKP_PlayerIsShown(playerName)
	for k, v in WebDKP_DkpTableToShow do
		if ( type(v) == "table" ) then
			local player = v[1];
			if ( player == playerName) then
				-- yes, they are being shown
				return 1;
			end
		end
	end
	--no, they arn't being shown
	return 0;
end


function WebDKP_ShowPlayer(playerName)
	if ( WebDKP_DkpTable[playerName] == nil ) then
		return;
	end
	local tableid = WebDKP_GetTableid();
	local playerClass = WebDKP_DkpTable[playerName]["class"];
	local playerDkp = WebDKP_DkpTable[playerName]["dkp_"..tableid];
	if ( playerDkp == nil ) then 
		playerDkp = 0;
	end
	local playerTier = floor((playerDkp-1)/WebDKP_TierInterval);
	if( playerDkp == 0 ) then
		playerTier = 0;
	end
	tinsert(WebDKP_DkpTableToShow,{playerName,playerClass,playerDkp,playerTier});
end