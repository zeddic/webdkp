------------------------------------------------------------------------
-- AWARDS	
------------------------------------------------------------------------
-- This file contains methods related to awarding/deducting DKP and 
-- items. It also contains methods for appending this data to the log file. 
------------------------------------------------------------------------


-- ================================
-- Called when user clicks on the 'award item' box. 
-- Gets the first selected player in the list, and the
-- contents of the award item edit boxes. Uses this to 
-- display a short blirb to the screen then recordes 
-- the changes
-- ================================
function WebDKP_AwardItem_Event()
	local name, class, guild;
	local cost = WebDKP_AwardItem_FrameItemCost:GetText();
	local item = WebDKP_AwardItem_FrameItemName:GetText();
	if ( item == nil or item=="" ) then
		WebDKP_Print("You must enter an item name.");
		PlaySound("igQuestFailed");
		return;
	end
	if ( cost == nil or cost=="") then
		WebDKP_Print("You must enter a cost for the item.");
		PlaySound("igQuestFailed");
		return;
	end

	local points = cost * -1;
	name = WebDKP_GetFirstSelectedPlayer();
	if(name == "NONE") then
		WebDKP_Print("You must select a player to award the item to");
		return; 
	end
	guild = WebDKP_GetGuildName(name);
	class = WebDKP_DkpTable[name]["class"];
	local tellLocation = WebDKP_GetTellLocation();
	if(not (tellLocation == "NONE") ) then
		SendChatMessage("WebDKP Item Award Notice",tellLocation);
		SendChatMessage("=============================",tellLocation);
		SendChatMessage("Item Awarded: "..item,tellLocation);
		SendChatMessage("Who: "..name,tellLocation);
		SendChatMessage("Cost: "..cost,tellLocation);
	else
		WebDKP_Print(item.." awarded to "..name.." for "..cost.." dkp.");
	end
	local forItem = "true";
	WebDKP_AddDKP2(name,guild,class,points,item,forItem);
	
	-- Update the table so we can see the new dkp status
	WebDKP_UpdateTableToShow();
	WebDKP_UpdateTable();
end

-- ================================
-- Called when user clicks on 'award dkp' on the award 
-- dkp tab. Gets data from the award dkp edit boxes. 
-- Uses this to display a little blirb, then recodes
-- this information for all players currently selected
-- (note, if player is hidden due to filter, they are automattically
-- deselected)
-- ================================
function WebDKP_AwardDKP_Event()
	local name, class, guild;
	local points = WebDKP_AwardDKP_FramePoints:GetText();
	local reason = WebDKP_AwardDKP_FrameReason:GetText();

	if ( points == nil or points=="") then
		WebDKP_Print("You must enter DKP points to award.");
		PlaySound("igQuestFailed");
		return;
	end
	
	local allGroupSelected = WebDKP_AllGroupSelected();
	local tellLocation = WebDKP_GetTellLocation();
	if(not (tellLocation == "NONE") ) then
		SendChatMessage("WebDKP Award Notice",tellLocation);
		SendChatMessage("=============================",tellLocation);
		SendChatMessage("Reason: "..reason,tellLocation);
		-- if all players selected display 'all players', otherwise, list all players being awarded
		if (allGroupSelected==true) then
			SendChatMessage("Awarding "..points.." points to all players in group.",tellLocation);
		else
			SendChatMessage("Awarding "..points.." points to the following players.",tellLocation);
		end
	else
		WebDKP_Print("Awarding "..points.." dkp for: "..reason);
		if (allGroupSelected==true) then
			WebDKP_Print("Awarded to entire group.");
		else
			WebDKP_Print("Awarded to following players:");
		end
		
	end
	-- go ahead and award all the points
	for k, v in WebDKP_DkpTable do
		if ( type(v) == "table" ) then
			if( v["Selected"] ) then
				name = k; 
				class = v["class"];
				guild = WebDKP_GetGuildName(name);
				if(not (tellLocation == "NONE") and not allGroupSelected) then
					SendChatMessage(name,tellLocation);
				elseif(not allGroupSelected) then
					WebDKP_Print(name);
				end
				WebDKP_AddDKP2(name,guild,class,points,reason,false);
			end
		end
	end
	
	-- Update the table so we can see the new dkp status
	WebDKP_UpdateTableToShow();
	WebDKP_UpdateTable();
end



-- ================================
-- Adds dkp to the specified user with the given properties. 
-- This writes the data first to a simple 'user'->'dkp' data structure
-- then calls another method to store the data in the log file
-- ================================
function WebDKP_AddDKP2(name,guild,class,points, reason, forItem)
	--First, add their guild to the straight up listings in memory.
	--This is just a plain UserName - DKP list
	
	local tableid = WebDKP_GetTableid();

	--make sure the user entry in the list exists. If not, create it
	if (not WebDKP_DkpTable[name]) then
		WebDKP_DkpTable[name] = {};
		WebDKP_DkpTable[name]["dkp_"..tableid] = 0;
	end
	if (WebDKP_DkpTable[name]["dkp_"..tableid] == nil) then
		WebDKP_DkpTable[name]["dkp_"..tableid] = 0;
	end
	--now add the dkp
	WebDKP_DkpTable[name]["dkp_"..tableid] = WebDKP_DkpTable[name]["dkp_"..tableid] + points;
	
	--Now we need to append them to the log that will be uploaded to the site
	WebDKP_AppendToLog(name, guild ,class, points, reason,forItem)
end

-- ================================
-- Appends the current information to the dkp log file
-- This is the variable that will eventually be saved
-- to a file and uploaded to the site
-- ================================
function WebDKP_AppendToLog(name,guild,class,points,reason,forItem)
	if(forItem == nil) then
		forItem = "false";
	end
	
	--first, make sure the dkp log exists
	if (not WebDKP_Log) then
		WebDKP_Log = {};
	end
	--next, make sure this player is in the log
	if (not WebDKP_Log[name]) then
		WebDKP_Log[name] = {};
		--also create an (info) entry that will keep track of how many log entries there
		--are for this player
		WebDKP_Log[name]["info"] = {
			["count"] = 0;
		}
	end

	local tableid = WebDKP_GetTableid();
	
	--get the current count of log entries for this player. 
	--this will be used to determine the next log count
	local newLogNumber = WebDKP_Log[name]["info"]["count"] +1;
	WebDKP_Log[name]["info"]["count"] = newLogNumber;
	
	--get the current time and zone that will be used to label 
	--this entry in the log
	local currentTime  = date("%Y-%m-%d %H:%M:%S");
	local zone = GetZoneText();

	--now make the entry to the log
	WebDKP_Log[name][newLogNumber] = {
		["name"] = name,
		["guild"] = guild,
		["class"] = class,
		["points"] = points,
		["reason"] = reason,
		["zone"] = zone,
		["awardedby"] = UnitName("player"),
		["date"] = currentTime,
		["foritem"] = forItem,
		["tableid"] = tableid
	};
end
