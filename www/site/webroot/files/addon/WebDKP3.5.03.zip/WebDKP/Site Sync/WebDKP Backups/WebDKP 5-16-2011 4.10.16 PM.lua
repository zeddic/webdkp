WebDKP_DkpTable = {
["Brygg"] = { 
     ["class"]="Mage", 
     ["dkp"]=12.00, 
     ["dkp_1"]=12.00, 
},
["Cather"] = { 
     ["class"]="Paladin", 
     ["dkp"]=18.00, 
     ["dkp_1"]=18.00, 
},
["Crazycoconut"] = { 
     ["class"]="Hunter", 
     ["dkp"]=12.00, 
     ["dkp_1"]=12.00, 
},
["Dkmetimbers"] = { 
     ["class"]="Death Knight", 
     ["dkp"]=12.00, 
     ["dkp_1"]=12.00, 
},
["Druamon"] = { 
     ["class"]="Druid", 
     ["dkp"]=18.00, 
     ["dkp_1"]=18.00, 
},
["Hamed"] = { 
     ["class"]="Mage", 
     ["dkp"]=18.00, 
     ["dkp_1"]=18.00, 
},
["Itasca"] = { 
     ["class"]="Priest", 
     ["dkp"]=18.00, 
     ["dkp_1"]=18.00, 
},
["Medico"] = { 
     ["class"]="Priest", 
     ["dkp"]=6.00, 
     ["dkp_1"]=6.00, 
},
["Menacing"] = { 
     ["class"]="Druid", 
     ["dkp"]=18.00, 
     ["dkp_1"]=18.00, 
},
["Purrito"] = { 
     ["class"]="Death Knight", 
     ["dkp"]=6.00, 
     ["dkp_1"]=6.00, 
},
["Silviasteeve"] = { 
     ["class"]="Warlock", 
     ["dkp"]=6.00, 
     ["dkp_1"]=6.00, 
},
["Tyrinas"] = { 
     ["class"]="Paladin", 
     ["dkp"]=18.00, 
     ["dkp_1"]=18.00, 
},
["Zealer"] = { 
     ["class"]="Priest", 
     ["dkp"]=19.00, 
     ["dkp_1"]=19.00, 
},
["Zevious"] = { 
     ["class"]="Priest", 
     ["dkp"]=15.00, 
     ["dkp_1"]=15.00, 
},
} 

WebDKP_Tables = {
["Main Table"] = { 
		["id"] = 1, 
},
}

WebDKP_Loot = {
}

WebDKP_Alts = {
}

WebDKP_WebOptions = {
["ZeroSumEnabled"] = 0,
["CombineAlts"] = 0,
["TiersEnabled"] = 0,
["TierSize"] = 50,
["LifetimeEnabled"] = 1,
}

